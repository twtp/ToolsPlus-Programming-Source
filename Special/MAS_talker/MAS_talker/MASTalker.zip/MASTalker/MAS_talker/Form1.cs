﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MAS_talker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime startTime = DateTime.Now;            
            string results = SQLCalls.MASCalls.MAS200.Retrieve(textBox1.Text);
            DateTime endTime = DateTime.Now;
            TimeSpan ts = endTime - startTime;

            statusLbl.Text = "Status: Took MAS " + ts.TotalSeconds.ToString("0.00") + " seconds to retrieve this data.";
            statusLbl.Refresh();
            textBox2.Text = results;            
            MAStoLVI(results, listView1);
        }

        public struct MASColumnHeader
        {
            public string Name;
            public int TypeID;
            public int Size;
        }              
        public void MAStoLVI(string responseData, ListView outputLV)
        {
            string ColumnData = "";
            string RowData = "";

            try
            {
                ColumnData = responseData.Split('[')[1].Split(']')[0];
                RowData = responseData.Split(new string[] { "rows\":[" }, StringSplitOptions.None)[1].Split(new string[] { "]}" }, StringSplitOptions.None)[0];
            }
            catch { MessageBox.Show("The last query errored as it returned nothing."); return; }
            string[] Columns = ColumnData.Split(new string[] { "{\"name\":\"" }, StringSplitOptions.RemoveEmptyEntries);
            for (int x = 0; x < Columns.GetLength(0); x++)
            {
                Columns[x] = Columns[x].Split('}')[0];
            }

            string[] Rows = RowData.Split(new string[]{"["},StringSplitOptions.RemoveEmptyEntries);
            for (int y = 0; y < Rows.GetLength(0); y++)
            {
                Rows[y] = Rows[y].Split(']')[0];
            }

            List<MASColumnHeader> finalColumns = new List<MASColumnHeader>();
            List<List<string>> finalRows = new List<List<string>>();
            foreach (string data in Columns)
            {
                MASColumnHeader mch = new MASColumnHeader();
                string Name, TypeID, Size = "";
                Name = data.Split('"')[0];
                TypeID = data.Split(new string[] { "typeID\":" }, StringSplitOptions.None)[1].Split(',')[0];
                Size = data.Split(new string[] { "size\":" }, StringSplitOptions.None)[1].Split(',')[0];
                mch.Name = Name;
                mch.TypeID = int.Parse(TypeID);
                mch.Size = int.Parse(Size);
                finalColumns.Add(mch);
            }
            foreach (string data in Rows)
            {
                List<string> fields = new List<string>();
                bool splitOffset = false;
                foreach (string field in data.Split(','))
                {
                    if (splitOffset == false)
                    {
                        splitOffset = true;
                        fields.Add(field.Replace("\"", ""));
                    }
                    else
                    {
                        fields.Add(field.Replace("\"", ""));
                    }
                }
                finalRows.Add(fields);
            }

            List<ListViewItem> resultsRows = new List<ListViewItem>();
            List<ColumnHeader> resultsColumns = new List<ColumnHeader>();

            outputLV.Items.Clear();
            outputLV.Columns.Clear();
            outputLV.Clear();
            outputLV.Refresh();
            outputLV.GridLines = true;
            outputLV.FullRowSelect = true;
            outputLV.View = View.Details;

            foreach (MASColumnHeader mch in finalColumns)
            {
                ColumnHeader tmpCol = new ColumnHeader();
                tmpCol.Text = mch.Name;
                tmpCol.Tag = mch;
                tmpCol.AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
                resultsColumns.Add(tmpCol);
            }
            foreach (List<string> fieldList in finalRows)
            {
                ListViewItem tmpLVI = new ListViewItem();
                bool firstCol = true;
                foreach(string fld in fieldList)
                {
                    if (firstCol == false)
                    {
                        tmpLVI.SubItems.Add(fld);
                    }
                    else
                    {
                        tmpLVI.Text = fld;
                        firstCol = false;
                    }

                }
                resultsRows.Add(tmpLVI);
            }

            foreach (ColumnHeader ch in resultsColumns)
            {
                outputLV.Columns.Add(ch);
            }
            foreach (ListViewItem lvi in resultsRows)
            {
                outputLV.Items.Add(lvi);
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
