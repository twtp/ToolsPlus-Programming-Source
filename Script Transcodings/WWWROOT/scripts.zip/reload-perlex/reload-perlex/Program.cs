using System;
using System.Collections.Generic;
using System.Text;

namespace reload_perlex
{
    class Program
    {
        static void Main(string[] args)
        {
            string url = "http://10.0.50.17/reload-
            System.Console.WriteLine(new System.Net.WebClient().DownloadString(url));
        }
    }
}
