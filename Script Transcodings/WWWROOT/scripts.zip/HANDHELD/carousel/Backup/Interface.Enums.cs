using System;
using System.Collections.Generic;
using System.Text;

namespace TP.Warehousing.White.Interface {

  internal enum LEDClearStyle {
    LightTree,
    OmniCell,
  };

}
