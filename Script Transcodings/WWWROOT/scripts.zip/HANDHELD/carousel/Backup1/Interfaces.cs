using System;
using System.Collections.Generic;
using System.Text;

namespace TP.Base {
  public interface IBasicForm {
    bool CanCloseWithoutWarning();
  }
}
