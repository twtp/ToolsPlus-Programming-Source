using System;
using System.Collections.Generic;
using System.Text;

namespace TP.Base.Printing {

  public enum Justification {
    Left,
    Right,
    Center,
  };

}
